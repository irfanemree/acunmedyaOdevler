﻿
namespace AttributeLibrary
{
    public class Class1
    {

    }
}
